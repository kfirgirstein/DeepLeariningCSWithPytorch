r"""
Use this module to write your answers to the questions in the notebook.

Note: Inside the answer strings you can use Markdown format and also LaTeX
math (delimited with $$).
"""

# ==============
# Part 2 answers


def part2_overfit_hp():
    wstd, lr, reg = 0, 0, 0
    # TODO: Tweak the hyperparameters until you overfit the small dataset.
    # ====== YOUR CODE: ======
    wstd, lr, reg = 0.1, 0.01, 0.05
    # ========================
    return dict(wstd=wstd, lr=lr, reg=reg)


def part2_optim_hp():
    wstd, lr_vanilla, lr_momentum, lr_rmsprop, reg, = 0, 0, 0, 0, 0

    # TODO: Tweak the hyperparameters to get the best results you can.
    # You may want to use different learning rates for each optimizer.
    # ====== YOUR CODE: ======
    wstd, lr_vanilla, lr_momentum, lr_rmsprop, reg, =  0.1, 0.01, 0.002, 0.00008, 0.01
    # ========================
    return dict(wstd=wstd, lr_vanilla=lr_vanilla, lr_momentum=lr_momentum,
                lr_rmsprop=lr_rmsprop, reg=reg)


def part2_dropout_hp():
    wstd, lr, = 0, 0
    # TODO: Tweak the hyperparameters to get the model to overfit without
    # dropout.
    # ====== YOUR CODE: ======
    wstd, lr, = 0.1, 0.001
    # ========================
    return dict(wstd=wstd, lr=lr)


part2_q1 = r"""
**Your answer:**


1. Yes, we expected to see a vey high accuracy on the training set for no dropout because of overfitting. On the other hand on the test data we expected for poor performance because of the overfitting to the small training set. Additionally we expected that adding dropout would create a better generalzation for the model as can be seen in the test accuracy.
2. We expect that increasing the dropout will increase out the performance up to some point. Too low dropout will create a model which is too similar to the no-dropout model, on the other hand creating a high dropout model will create a model which sort of "doesn't look at the data". Therefore, the best dropout in his case would be somewhere in between and as we can see in the graph, our best model is with 0.4 dropout.

"""

part2_q2 = r"""
**Your answer:**


Yes, this is possible. y_hat is the probability vector for each of the classes, lets call the probability of the class with the highest probability our "confidence" in that class. We calculate the accuracy as the amount of samples in which the class with highest "confidence" (or probability) is the same as the true class divided by all the amount of total samples. There is a situation where we predict more samples correctly but with less "confidence" (the probability) in each of the the samples. Therefore the accuracy will increase and the loss may increase in the same time.

"""
# ==============

# ==============
# Part 3 answers

part3_q1 = r"""
**Your answer:**


1. It appears that the depth of the network doesn't increase the results. As can be seen we get the best results when L = 2. We beleive that the reason for this is that placing layers which have the same amount of channels/filters one after another doesn't enhance the performance.
2. It can be seen that for L=8 and L=16 the network wasn't trainable. We believe that there were two possible reasons for this, first is that once we take more layers there are more layers of pooling which minimize the input dimensions by half each time until there is not enouth data in the input. The second reason is what we described in 1 which the number of layers with the same filters amount also affect the network being not trainable.
The first thing that can be done is to increase pool-every parameter. The second thing is to make changing amount of filters in each layer. At this point we assumed that using residual networks which contains skips may improve the performance over cnn. This turned up to be true up ahead.

"""

part3_q2 = r"""
**Your answer:**


In experiment 1.2 we can see that as in experiment 1.1, increasing the number of layers with the same amount of filters doesn't improve the results. Additionally in experiment 1.2 we learn a new thing, we learn that increasing the number of filters per layer also improves the results.

"""

part3_q3 = r"""
**Your answer:**


In this experiment we can see that even when we use a different amount of filters in each layer, creating a too deep network with many layers doesn't manage to do any learning. Additionally we can see that the only model that manage to learn is when L = 2 but we get into overfitting pretty quick.

"""

part3_q4 = r"""
**Your answer:**


Here we can see that when using ResidualNetwork we can use deeper networks which would enhance the performance of the network. Additionally we can see that with more simple networks where we use the same amount of filters in every layer we get much quicker into overfitting than when using more complex networks with a differentiating amount of filters in every layer - meaning more complex networks got a better potential learning this dataset.
"""

part3_q5 = r"""
**Your answer:**


1. We added the following improvements:
    - We used Residual Blocks - We wanted to have the option to skip some layers, as can be seen in experiment 1.4 using residual networks improved the performance with deeper networks.
    - We used dropout - we hoped that increasing the dropout will also increase the generalization of the model.
    - We used AvgPooling instead of MaxPooling - We assumed that using avg pooling would work better on images from CIFAR10 than MaxPooling.
    - We used normalization - normalization is used to increase the learning rate because it sets a constant range of values.
2. In this experiment we got slightly better results than what we've seen in the experiment 1. As we expected we got the best performance when L was 6 and 9. As can be seen when L=3 we got much faster into overfitting and on the other hand when L=12 the model didn't manage to learn. This is exactly what we've learned in experiment 1. Hopefully the small changes we made in the network the ones which are responsible for the slight enhancement in the performance.

"""
# ==============